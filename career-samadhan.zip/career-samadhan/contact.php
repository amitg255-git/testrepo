<?php include 'head.php'  ?>

<div class="kf_inr_banner">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                    	<!--KF INR BANNER DES Wrap Start-->
                        <div class="kf_inr_ban_des">
                        	<div class="inr_banner_heading">
								<h3>contact us</h3>
                        	</div>
                           
                            <div class="kf_inr_breadcrumb">
								<ul>
									<li><a href="#">Home</a></li>
									<li><a href="#">contact</a></li>
								</ul>
							</div>
                        </div>
                        <!--KF INR BANNER DES Wrap End-->
                    </div>
                </div>
            </div>
        </div>

        <!--Banner Wrap End-->

    	<!--Content Wrap Start-->
    	<div class="kf_content_wrap">
    		
    		<section>
    			<div class="container">
    				<!--CONTACT HEADING Start-->
    				
    				<!--CONTACT HEADING END-->
                    <div class="contct_wrap">
                        <div class="row">
                            <div class="col-md-8">
                            <form  method="post" action="enquary_db.php">
                                    <div class="contact_des">
                                        <h4>Contact Form</h4>
                                        <div class="inputs_des des_2">
                                            <input type="text" name="name" placeholder="Name"><i class="fa fa-user"></i>
                                        </div>
    
                                        <div class="inputs_des des_2">
                                            <input type="text"  name="email" placeholder="E-mail">
                                            <i class="fa fa-envelope-o"></i>
                                        </div>
                                        <div class="inputs_des des_2">
                                            <input type="text" name="mobile"  placeholder="Phone">
                                            <i class="fa fa-phone"></i>
                                        </div>
                                        <div class="inputs_des des_2">
                                            <input type="text" name="subj"  placeholder="Subject">
                                            <i class="fa fa-phone"></i>
                                        </div>
                                        <div class="inputs_des des_3">
                                            <textarea name="notes"></textarea>
                                            <i class="fa fa-comments-o"></i>
                                        </div>
                                        <div class="inputs_des des_2">
                                        <input class="contact_btn" name="submit" value="submit" type="submit">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-4">
                                <div class="contact_heading">
                                    <h4>Contact info</h4>
                                    <!-- <p>Sed ut imperdiet nisi. Proin condimentum . Etiam pharetra erat sed fermentum feugiat velit mauris egestas quam ut aliquam .</p> -->
                                </div>
                                <ul class="contact_meta">
                                    <li><i class="fa fa-globe"></i>A-20, Faiyaz residency 3rd floor near surya narayan Mandir Ali Nagar anisabad -patna 800002</li>
                                    <li><i class="fa fa-phone"></i><a href="#"> +91 9507769410</a></li>
                                    <li><i class="fa fa-envelope-o"></i><a href="#"> info@careersamadhan.in</a></li>
                                </ul>
                           
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3598.6125167680016!2d85.08918037278129!3d25.584555166116434!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ed57e30f53245d%3A0xd672f5dbddba7160!2sFaiyaz%20Residency%2C%20A%2F20%2C%20Bypass%20Rd%2C%20Behind%20SBI%2C%20Ali%20Nagar%20Colony%2C%20Police%20Colony%2C%20Phulwari%20Sharif%2C%20Patna%2C%20Bihar%20800002!5e0!3m2!1sen!2sin!4v1732260888854!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            </div>
                        </div>
	    			</div>
    			</div>
    		</section>
    	</div>
<?php include 'foot.php'  ?>