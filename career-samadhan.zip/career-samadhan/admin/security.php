<?php
include "conn.php";
session_start();
if (empty($_SESSION["admin"]) && empty($_SESSION["name"])) {
	header('location:index.php');
} else {
?>

	<!DOCTYPE html>
	<html lang="en">

	<head>
		<title>Change Password</title>
		<!-- META TAGS -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php include 'includes/link.php'; ?>
	</head>

	<body data-ng-app="">
		<!--MOBILE MENU-->
		<?php include 'includes/mobile-menu.php'; ?>
		<!--HEADER SECTION-->
		<section>
			<!--TOP SECTION-->
			<?php include 'includes/menu.php'; ?>
			<!--TOP SECTION-->
			<!--DASHBOARD SECTION-->
			<div class="dashboard">
				<div class="db-left">
					<!-- <div class="db-left-1">
					<h4>Jana Novakova</h4>
					<p>Newyork, United States</p>
				</div> -->
					<div class="db-left-2">
						<?php include 'includes/admin-panel.php'; ?>
					</div>
				</div>
				<div class="db-cent">
					<div class="db-cent-1">
						<p>Hi
							<?php echo $_SESSION['name']; ?>,
						</p>
						<h4>Welcome to your dashboard</h4>
					</div>
					<div class="db-profile"> <img src="images/logo.png" alt="">
						<h4>
							<?php echo $_SESSION['name']; ?>
						</h4>
					</div>
					<?php

					$query = "SELECT * FROM admin";
					$result = mysqli_query($conn, $query);
					$row = mysqli_fetch_assoc($result);
					?>
					<div class="db-profile-edit">
						<form class="col s12" action="update/passowrd.php?id=<?php echo $row['admin_id']; ?>" method="post">
							<div>
								<label class="col s4">User id / Email Address</label>
								<div class="input-field col s8">
									<input type="text" name="username" value="<?php echo $row['admin_user_id']; ?>" class="form-control">
								</div>
							</div>
							<div>
								<label class="col s4">New Password</label>
								<div class="input-field col s8">
									<input type="password" name="password" class="form-control">
								</div>
							</div>
							<div>
								<label class="col s4">Conform Password</label>
								<div class="input-field col s8">
									<input type="password" name="cnf_password" class="form-control">
								</div>
							</div>
							<div>
								<div class="input-field col s8">
									<input type="submit" name="submit" value="Update Password" class="waves-effect waves-light pro-sub-btn" id="pro-sub-btn">
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<!--END DASHBOARD SECTION-->
			<!--TOP SECTION-->
		</section>
		<!--END HEADER SECTION-->

		<!--ALL SCRIPT FILES-->
		<?php include 'includes/script.php'; ?>
	</body>

	</html>
<?php } ?>