<?php
session_start();
include 'conn.php';

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM admin WHERE admin_user_id = '$username' AND admin_password = '$password'";
    $result = $conn->query($query);
    $row = mysqli_fetch_assoc($result);

    if ($result->num_rows == 1) {
        // Authentication successful
        $_SESSION['admin'] = $username;
        $_SESSION['name'] = $row['admin_name'];
        header('Location: dashboard.php'); // Redirect to a welcome page
    } else {
        // Authentication failed
        echo "Invalid username or password.";
    }

    $conn->close();
// }
?>
