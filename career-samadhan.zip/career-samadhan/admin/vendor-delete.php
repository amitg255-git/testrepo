<?php include "conn.php";

$id = $_GET['id'];
$query = "DELETE FROM vendor WHERE v_id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert('Vendor Deleted');
            window.location.href='vendor-list.php';
        </script>";
}
