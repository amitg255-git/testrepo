<?php include "conn.php";

$id = $_GET['id'];
$query = "DELETE FROM add_state WHERE cat_id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert(' Deleted');
            window.location.href='add-state.php';
        </script>";
}
