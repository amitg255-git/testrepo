<!DOCTYPE html>
<html lang="en">

<head>
    <title>forget Password</title>
    <!-- META TAGS -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php include 'includes/link.php'; ?>
</head>

<body data-ng-app="">
    <section>
        <div class="log-in-pop">
            <div class="log-in-pop-left hide-menu">
                <img src="images/logo1.png" class="img-responsive">
                <h1>Hello... <span>{{ name }}</span></h1>
                <p class=" hidden-sm hidden-xs ">
                    Don't have an account? Create your account. It's take less then a
                    minutes
                </p>
            </div>
            <div class="log-in-pop-right">
                <h2>Password Reset</h2>
                <p>
                    Don't have an account? Create your account. It's take less then a
                    minutes
                </p>
                <form action="reset-password.php" class="s12" method="post">
                    <div>
                        <div class="input-field s12">
                            <input type="text" data-ng-model="name" class="validate" placeholder="Enter userid or email" />
                            <label>User name</label>
                        </div>
                    </div>
                    <div>
                        <div class="input-field s4">
                            <input type="submit" value="verify now" class="waves-effect waves-light log-in-btn btn-block text-center" />
                        </div>
                    </div>
                    <div>
                        <div class="input-field s12">
                            <a href="index.php">Login now</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <!--ALL SCRIPT FILES-->
    <?php include './includes/script.php' ?>
</body>

</html>