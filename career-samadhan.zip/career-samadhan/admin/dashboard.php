<?php
include "conn.php";
session_start();
if (empty($_SESSION["admin"]) && empty($_SESSION["name"])) {
	header('location:index.php');
} else {
?>
	<!DOCTYPE html>
	<html lang="en">

	<head>
		<title>Admin Panel | Dashboard</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php include 'includes/link.php'; ?>
	</head>

	<body data-ng-app="">
		<!--MOBILE MENU-->
		<?php include 'includes/mobile-menu.php'; ?>
		<!--HEADER SECTION-->
		<section>
			<!--TOP SECTION-->
			<?php include 'includes/menu.php'; ?>
			<div class="dashboard">
				<div class="db-left">
					<div class="db-left-2">
						<?php include 'includes/admin-panel.php'; ?>
					</div>
				</div>
				<div class="db-cent">
					<div class="db-cent-1">
						<p>Hi
							<b>
								<?php echo $_SESSION['name']; ?>
							</b>
						</p>
						<h4>Welcome to your dashboard</h4>
					</div>
					<div class="db-cent-2">
						<div class="db-2-main-1">
							<?php
							$query = "SELECT * FROM home_slider";
							$result = mysqli_query($conn, $query);
							$slider_count = mysqli_num_rows($result);
							?>
							<div class="db-2-main-2"> <img src="images/icon/dbc5.png" alt=""> <a href="add-category.php"><span>Add College Category</span></a>
								<h2>
									<?php echo $slider_count; ?>
								</h2>
							</div>
						</div>
						<div class="db-2-main-1">
							<?php
							$query = "SELECT * FROM add_category";
							$result = mysqli_query($conn, $query);
							$category_count = mysqli_num_rows($result);
							?>
							<div class="db-2-main-2"> <img src="images/icon/dbc6.png" alt=""> <a href="add-sub-category.php"><span>Add College And Info</span></a>
							<h2>
								<h2>
									<?php echo $category_count; ?>
								</h2>
							</div>
							<?php ?>
						</div>
						<div class="db-2-main-1">
							<?php
							$query = "SELECT * FROM add_sub_category";
							$result = mysqli_query($conn, $query);
							$sub_cat_count = mysqli_num_rows($result);
							?>
							<div class="db-2-main-2"> <img src="images/icon/dbc3.png" alt=""> <a href="add-college%20course.php"><span>Add college Course</span></a>
								<h2>
									<?php echo $sub_cat_count; ?>
								</h2>
							</div>
						</div>
						<div class="db-2-main-1">
							<?php
							$query = "SELECT * FROM vendor_booking";
							$result = mysqli_query($conn, $query);
							$booking_count = mysqli_num_rows($result);
							?>
							<div class="db-2-main-2"> <img src="images/icon/dbc3.png" alt=""> <a href="vendor-booking.php"><span>Apply</span></a>
								<h2>
									<?php echo $booking_count; ?>
								</h2>
							</div>
						</div>
						<div class="db-2-main-1">
							<?php
							$query = "SELECT * FROM vendor";
							$result = mysqli_query($conn, $query);
							$vendor_count = mysqli_num_rows($result);
							?>
							<div class="db-2-main-2"> <img src="images/icon/dbc3.png" alt=""> <a href="profile.php"><span>Profile</span></a>
								<h2>
									<?php echo $vendor_count; ?>
								</h2>
							</div>
						</div>
						<div class="db-2-main-1">
							<?php
							$query = "SELECT * FROM apply_job";
							$result = mysqli_query($conn, $query);
							$gallery_count = mysqli_num_rows($result);
							?>
							<div class="db-2-main-2"> <img src="images/icon/dbc3.png" alt=""> <a href="appy_job.php"><span>Job Application</span></a>
							<h2>
								<h2>
									<?php echo $gallery_count; ?>
								</h2>
							</div>
						</div>
						<div class="db-2-main-1">
							
							<div class="db-2-main-2"> <img src="images/icon/dbc3.png" alt=""> <a href="logout.php"><span>Logout</span></a>
							<h2>
								<h2>
									1
								</h2>
							</div>
						</div>
						<div class="db-2-main-1">
							<?php
							$query = "SELECT * FROM contact";
							$result = mysqli_query($conn, $query);
							$contact_count = mysqli_num_rows($result);
							?>
							<div class="db-2-main-2"> <img src="images/icon/dbc3.png" alt=""> <span>The Edu Nova</span>
								<h2>
									<?php echo $contact_count; ?>
								</h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!--ALL SCRIPT FILES-->
		<?php include 'includes/script.php'; ?>
	</body>

	</html>
<?php } ?>