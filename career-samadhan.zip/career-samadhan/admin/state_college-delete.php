<?php include "conn.php";

$id = $_GET['id'];
$query = "DELETE FROM state_college WHERE id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert('College Deleted');
            window.location.href='add-college-list.php';
        </script>";
}
