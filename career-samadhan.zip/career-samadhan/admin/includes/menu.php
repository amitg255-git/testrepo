<div class="menu-section">
    <div class="container">
        <div class="row">
            <div class="logo">
                <a href="dashboard.php"><img src="images/logo.png" alt="" height="80" /> </a>
            </div>
        </div>
    </div>
</div>