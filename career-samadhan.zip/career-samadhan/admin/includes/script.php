<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/angular.min.js"></script>
<script src="js/bootstrap.js" type="text/javascript"></script>
<script src="js/materialize.min.js" type="text/javascript"></script>
<script src="js/jquery.mixitup.min.js" type="text/javascript"></script>
<script src="js/custom.js"></script>
<script src="js/datatables.min.js" type="text/javascript"></script>