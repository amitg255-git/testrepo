 <ul>
    <li><a href="dashboard.php"><img src="images/icon/db1.png" alt="" /> Dashboard</a></li>
    
    <!-- <li><a href="add-home-slider.php"><img src="images/icon/db1.png" alt="" /> Home Slider</a></li> -->
    <li><a href="add-category.php"><img src="images/icon/db1.png" alt="" />College Catogeory </a></li>
    <li><a href="add-sub-category.php"><img src="images/icon/db1.png" alt="" /> Add College and info</a></li>
    <li><a href="add-college course.php"><img src="images/icon/db1.png" alt="" /> Add College Course</a></li>
    <li><a href="add-faq.php"><img src="images/icon/db1.png" alt="" /> Add Faq</a></li>
    <li><a href="add-state1.php"><img src="images/icon/db1.png" alt="" />Add State </a></li>

    <li><a href="add-state.php"><img src="images/icon/db1.png" alt="" /> Add College in India/Aboroad</a></li>
    <!-- <li><a href="add-state-info.php"><img src="images/icon/db1.png" alt="" /> Add College Info</a></li> -->
    <li><a href="add-college-list.php"><img src="images/icon/db1.png" alt="" />Add College for state</a></li>
    <li><a href="add-course.php"><img src="images/icon/db1.png" alt="" />Add Course </a></li>


   
   
 

    <li><a href="vendor-booking.php"><img src="images/icon/db2.png" alt="" />Apply</a></li>   
    <li><a href="enquary.php"><img src="images/icon/db2.png" alt="" />Enquary</a></li> 
      

   
    <li><a href="appy_job.php"><img src="images/icon/db2.png" alt="" /> Manage Job Application</a></li>

    <li><a href="profile.php"><img src="images/icon/db6.png" alt="" /> Profile</a></li>
    <li><a href="security.php"><img src="images/icon/db6.png" alt="" /> Security</a></li>
    <li><a href="logout.php"><img src="images/icon/db8.png" alt="" /> Logout</a></li>
   

    <!-- <li><a href="add_collaboration.php"><img src="images/icon/db1.png" alt="" /> Collaboration</a></li>
    
    <li><a href="vendor-list.php"><img src="images/icon/db1.png" alt="" /> Vendor list </a></li>
    <li><a href="add-gallery.php"><img src="images/icon/db7.png" alt="" /> Manage Gallery</a></li>
    <li><a href="add-video.php"><img src="images/icon/db6.png" alt="" /> Manage Video Gallery</a></li>
    <li><a href="add-blog.php"><img src="images/icon/db6.png" alt="" /> Blog Manage</a></li>
    <li><a href="add-testimonial.php"><img src="images/icon/db6.png" alt="" /> Testimonial Manage</a></li>
    <li><a href="contact-enquiry.php"><img src="images/icon/db6.png" alt="" /> Contact Enquiry</a></li>
    <li><a href="login-data.php"><img src="images/icon/db6.png" alt="" /> Login Enquiry</a></li>
    <li><a href="feedback-data.php"><img src="images/icon/db6.png" alt="" /> Feedback Enquiry</a></li> -->


    
</ul>