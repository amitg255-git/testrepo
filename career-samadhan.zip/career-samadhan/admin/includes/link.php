<link rel="shortcut icon" href="images/fav.ico" type="image/x-icon" />
<link rel="stylesheet" href="css/font-awesome.min.css" />
<link href="css/materialize.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" />
<link href="css/datatables.min.css" rel="stylesheet" type="text/css" />
<link href="css/default.css" rel="stylesheet" type='text/css' />



