<section>
  <div class="mm">
    <div class="mm-inn">
      <div class="mm-logo">
        <a href="user-dashboard.php"><img src="images/logo.png" alt="" height="70" /> </a>
      </div>
      <div class="mm-icon">
        <span><i class="fa fa-bars show-menu" aria-hidden="true"></i></span>
      </div>
      <div class="mm-menu">
        <div class="mm-close">
          <span><i class="fa fa-times hide-menu" aria-hidden="true"></i></span>
        </div>
        <ul>
          <li><a href="dashboard.php"><img src="images/icon/db1.png" alt="" /> Dashboard</a></li>
          <li><a href="add-category"><img src="images/icon/db1.png" alt="" /> College Catogeory </a></li>
          <li><a href="add-sub-category.php"><img src="images/icon/db1.png" alt="" /> Add College and info</a></li>
          <li><a href="add-college%20course.php"><img src="images/icon/db1.png" alt="" />Add College Course</a></li>
          <li><a href="add-faq.php"><img src="images/icon/db1.png" alt="" /> Add Faq</a></li>

          <li><a href="add-state1.php"><img src="images/icon/db1.png" alt="" />Add State </a></li>
<li><a href="add-state.php"><img src="images/icon/db1.png" alt="" /> Add College in India/Aboroad</a></li>
<!-- <li><a href="add-state-info.php"><img src="images/icon/db1.png" alt="" /> Add College Info</a></li> -->
<li><a href="add-college-list.php"><img src="images/icon/db1.png" alt="" />Add College for state</a></li>
<li><a href="add-course.php"><img src="images/icon/db1.png" alt="" />Add Course </a></li>


          <li><a href="vendor-booking.php"><img src="images/icon/db2.png" alt="" /> Apply</a></li>
          <li><a href="enquary.php"><img src="images/icon/db7.png" alt="" /> Enquary</a></li>
          <li><a href="appy_job.php"><img src="images/icon/db6.png" alt="" /> Manage Job Application</a></li>
          <li><a href="profile.php"><img src="images/icon/db6.png" alt="" />  Profile</a></li>
          <li><a href="security.php"><img src="images/icon/db6.png" alt="" /> Security</a></li>
          <li><a href="logout.php"><img src="images/icon/db6.png" alt="" />Logout</a></li>
    
      </div>
    </div>
  </div>
</section>