<?php
include "conn.php";
session_start();
if (empty($_SESSION["admin"]) && empty($_SESSION["name"])) {
    header('location:index.php');
} else {
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Add College 2</title>
        <!-- META TAGS -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include 'includes/link.php'; ?>
        <script src="//cdn.ckeditor.com/4.23.0-lts/basic/ckeditor.js"></script>

    </head>

    <body data-ng-app="">
        <!--MOBILE MENU-->
        <?php include 'includes/mobile-menu.php'; ?>
        <!--HEADER SECTION-->
        <section>
            <!--TOP SECTION-->
            <?php include 'includes/menu.php'; ?>
            <!--TOP SECTION-->
            <!--DASHBOARD SECTION-->
            <div class="dashboard">
                <div class="db-left">
                    <div class="db-left-2">
                        <?php include 'includes/admin-panel.php'; ?>
                    </div>
                </div>
                <div class="db-cent">
                    <div class="db-cent-1">
                        <p>
                        
                        </p>
                        <h4>Welcome to your Dashboard</h4>
                    </div>
                    <div class="db-cent-3">
                        <div class="db-cent-table db-com-table">
                            <div class="enquiry-form">
                                <div class="form-heading">
                                    <h4>Add college </h4>
                                </div>
                                <div class="form-body">
                                    <form action="college_course-list_db.php" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <!-- <div class="col-md-5">
                                                <label> Add Images</label>
                                                <input type="file" name="image" class="form-control">
                                            </div> -->


                                            <div class="col-md-5 mt-10">
                                                <label>Category</label>
                                                <select name="category" class="form-control">
                                                    <option value="" disabled selected>Select Category</option>
                                                    <?php
                                                    $query = "SELECT * FROM add_state ";
                                                    $result =mysqli_query($conn, $query);
                                                    while ($row = mysqli_fetch_assoc($result)) {
                                                    ?>
                                                        <option value="<?php echo $row['cat_id']; ?>">
                                                            <?php echo $row['cat_name']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-md-5">
                                                <label> Enter College name</label>
                                                <input type="text" name="college_name" class="form-control" required >
                                            </div>
                                            <div class="col-md-5">
                                                <label> Select Country</label>
                                    
                                                <select name="country"  class="form-control">
                                                    <option value="1">India</option>
                                                    <option value="2">Abroad</option>
                                                </select>
                                            </div>
                                            <div class="col-md-5">
                                                <label> Enter College Type</label>
                                    
                                                <select name="type"  class="form-control">
                                                    <option value="1">Private</option>
                                                    <option value="2">Goverment</option>
                                                </select>
                                            </div>

                                            <div class="col-md-5">
                                                <label>Enter ESTD</label>
                                                <input type="text" name="estd" class="form-control" required >
                                            </div>
                                            <div class="col-md-5">
                                                <label>Total Intak</label>
                                                <input type="text" name="intak" class="form-control" required >
                                            </div>
                                            </div>
                                            <div class="col-md-2">
                                                <label></label>
                                                <input type="submit" name="submit" value="Add" class="btn btn-success btn-block mt-10" class="form-control">
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="db-title">
                                <h3><img src="images/icon/dbc5.png" alt="" /> Manage College Course</h3>
                            </div>
                            <div class="table-responsive">
                                <table id="booking" class="table table-striped table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>S no.</th>
                                            <th>category</th>
                                             <th>College Name</th>
                                            <th>State</th>
                                            <th>Type</th>
                                            <th>Country</th>
                                            <th>Estd</th>
                                            <th>Total Intak</th>
                                            <th>Add date</th>
                                           
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = '1';
                                        $query = "SELECT * FROM state_college order by id asc";
                                        $result = mysqli_query($conn, $query);
                                        while ($row = mysqli_fetch_assoc($result)) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <?php echo $i++; ?>
                                                </td>
                                                <td>
                                                <?php  $cat=$row['category']; 
                                                
                                                $query2 = "SELECT * FROM add_state Where cat_id=$cat";
                                                $result2 = mysqli_query($conn, $query2);
                                                $row2 = mysqli_fetch_assoc($result2);
                                                echo $cat2=$row2['cat_name'];
                                                ?>
                                                </td>
                                                <td>
                                                <?php echo $row['college_name']; ?>
                                                </td> 
                                                <td>
                                                    <?php echo $row2['state']; ?>
                                                </td>
                                                <td>
                                                <?php if($row['type']==1){
                                                        echo "Private";
                                                    } ?>
                                                      <?php if($row['type']==2){
                                                        echo "Goverment";
                                                    } ?>
                                                    
                                                
                                                </td>
                                                <td>
                                                   
                                                    <?php if($row['country']==1){
                                                        echo "India";
                                                    } ?>
                                                      <?php if($row['country']==2){
                                                        echo "Abroad";
                                                    } ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['estd']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['intak']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['date']; ?>
                                                </td>
                                                
                                                <td>
                                                    <a href="state_college-delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a>
                                                </td>
                                            </tr>
                                        <?php } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--END DASHBOARD SECTION-->
        </section>
        <!--END HEADER SECTION-->

        <!--ALL SCRIPT FILES-->
        <?php include 'includes/script.php'; ?>
        <script>
            new DataTable('#booking');
            CKEDITOR.replace('editor');
        </script>
    </body>

    </html>
<?php } ?>