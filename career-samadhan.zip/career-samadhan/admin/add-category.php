<?php
include "conn.php";
session_start();
if (empty($_SESSION["admin"]) && empty($_SESSION["name"])) {
    header('location:index.php');
} else {
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Add Category</title>
        <!-- META TAGS -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include 'includes/link.php'; ?>
        <script src="//cdn.ckeditor.com/4.23.0-lts/basic/ckeditor.js"></script>

    </head>

    <body data-ng-app="">
        <!--MOBILE MENU-->
        <?php include 'includes/mobile-menu.php'; ?>
        <!--HEADER SECTION-->
        <section>
            <!--TOP SECTION-->
            <?php include 'includes/menu.php'; ?>
            <!--TOP SECTION-->
            <!--DASHBOARD SECTION-->
            <div class="dashboard">
                <div class="db-left">
                    <div class="db-left-2">
                        <?php include 'includes/admin-panel.php'; ?>
                    </div>
                </div>
                <div class="db-cent">
                    <div class="db-cent-1">
                        <p>
                        
                        </p>
                        <h4>Welcome to your Dashboard</h4>
                    </div>
                    <div class="db-cent-3">
                        <div class="db-cent-table db-com-table">
                            <div class="enquiry-form">
                                <div class="form-heading">
                                    <h4>Add college </h4>
                                </div>
                                <div class="form-body">
                                    <form action="add_category_db.php" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <!-- <div class="col-md-5">
                                                <label> Add Images</label>
                                                <input type="file" name="image" class="form-control">
                                            </div> -->
                                            <div class="col-md-5">
                                                <label>College  Catogeory/state</label>
                                                <input type="text" name="name" class="form-control">
                                            </div>
                                            
                                            <div class="col-md-2">
                                                <label></label>
                                                <input type="submit" name="submit" value="Add Category" class="btn btn-success btn-block mt-10" class="form-control">
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="db-title">
                                <h3><img src="images/icon/dbc5.png" alt="" /> Manage College Catogeory</h3>
                            </div>
                            <div class="table-responsive">
                                <table id="booking" class="table table-striped table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>S no.</th>
                                            <!-- <th>Image</th> -->
                                            <th>Name</th>
                                           
                                            <th>Add date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = '1';
                                        $query = "SELECT * FROM add_category order by cat_id DESC";
                                        $result = mysqli_query($conn, $query);
                                        while ($row = mysqli_fetch_assoc($result)) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <?php echo $i++; ?>
                                                </td>
                                                <!-- <td><img class="materialboxed" src="<?php //echo $row['cat_image']; ?>" width="70">
                                                </td> -->
                                                <td>
                                                    <?php echo $row['cat_name']; ?>
                                                </td>
                                                
                                                <td>
                                                    <?php echo $row['cat_add_date']; ?>
                                                </td>
                                                <td><a href="#" class="db-success">
                                                        <?php echo $row['cat_status']; ?>
                                                    </a></td>
                                                <td>
                                                    <a href="add-category-delete.php?id=<?php echo $row['cat_id']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a>
                                                </td>
                                            </tr>
                                        <?php } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--END DASHBOARD SECTION-->
        </section>
        <!--END HEADER SECTION-->

        <!--ALL SCRIPT FILES-->
        <?php include 'includes/script.php'; ?>
        <script>
            new DataTable('#booking');
            CKEDITOR.replace('editor');
        </script>
    </body>

    </html>
<?php } ?>