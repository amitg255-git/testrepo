<?php
session_start();
include "../conn.php";
$id = $_GET['id'];
if (isset($_POST['submit'])) {
    $user = $_POST['username'];
    $password = $_POST['password'];
    $cnf_password = $_POST['cnf_password'];
    $query = "SELECT * FROM admin WHERE admin_id ='$id'";
    $result = mysqli_query($conn, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        if ($row['admin_user_id'] == $user) {
            if ($password != $cnf_password) {
                echo "<script>
                        alert('Password Not Match');
                        window.location.href='../profile.php';
                    </script>";
            }
            $query = "UPDATE admin SET admin_password = '$cnf_password' WHERE admin_id = '$id'";

            mysqli_query($conn, $query) or die(mysqli_error($conn));
            echo "<script>
                    alert('Password Successfully Update');
                    window.location.href='../profile.php';
                </script>";
        } else {
            echo "<script>
                    alert('No Records Found');
                    window.location.href='../profile.php';
                </script>";
        }

    }
}