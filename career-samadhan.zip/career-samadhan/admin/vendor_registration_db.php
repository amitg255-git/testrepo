<?php
include "conn.php";
error_reporting(0);
if (isset($_POST['submit'])) {
    $user = $_POST['user_name'];
    $mobile = $_POST['mobile'];
    $alter_mobile = $_POST['alter_mobile'];
    $city = $_POST['city'];
    $category = $_POST['cat_id'];
    $sub_category = implode(',', $_POST['sub_cat_id']);
    $address = $_POST['address'];
    $about = $_POST['about'];
    $stating_price = $_POST['starting_price'];
    $adhar_no = $_POST['adhar_no'];
    $camera_brand = $_POST['camera_brand'];
    $camera_modal = $_POST['camera_modal'];
    $lens = $_POST['lens'];
    $drone_brand = $_POST['drone_brand'];
    $drone_modal = $_POST['drone_modal'];
    $software = $_POST['software'];
    $account = $_POST['account'];
    $account_ifsc = $_POST['account_ifsc'];
    $branch = $_POST['branch'];
    $half_price = $_POST['half_price'];
    $full_price = $_POST['full_price'];
    $extra_price = $_POST['extra_price'];
    $link1 = $_POST['link1'];
    $link2 = $_POST['link2'];
    $link3 = $_POST['link3'];
    $link4 = $_POST['link4'];
    $term = $_POST['term'];

    $file = $_FILES['cover'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder);
            }
        }
    }

    $file_name = $_FILES['video1']['name'];
    $file_temp = $_FILES['video1']['tmp_name'];
    $file_size = $_FILES['video1']['size'];
    if ($file_size < 50000000) {
        $file = explode('.', $file_name);
        $end = end($file);
        $allowed_ext = array('avi', 'flv', 'wmv', 'mov', 'mp4');
        if (in_array($end, $allowed_ext)) {
            $name = date("Ymd") . time();
            $video1 = "images/vendor-video/" . $name . "." . $end;
            move_uploaded_file($file_temp, $video1);
        }
    }
    $file_name = $_FILES['video2']['name'];
    $file_temp = $_FILES['video2']['tmp_name'];
    $file_size = $_FILES['video2']['size'];
    if ($file_size < 50000000) {
        $file = explode('.', $file_name);
        $end = end($file);
        $allowed_ext = array('avi', 'flv', 'wmv', 'mov', 'mp4');
        if (in_array($end, $allowed_ext)) {
            $name = date("Ymd") . time();
            $video2 = "images/vendor-video/" . $name . "." . $end;
            move_uploaded_file($file_temp, $video2);
        }
    }
    $file_name = $_FILES['video3']['name'];
    $file_temp = $_FILES['video3']['tmp_name'];
    $file_size = $_FILES['video3']['size'];
    if ($file_size < 50000000) {
        $file = explode('.', $file_name);
        $end = end($file);
        $allowed_ext = array('avi', 'flv', 'wmv', 'mov', 'mp4');
        if (in_array($end, $allowed_ext)) {
            $name = date("Ymd") . time();
            $video3 = "images/vendor-video/" . $name . "." . $end;
            move_uploaded_file($file_temp, $video3);
        }
    }
    $file_name = $_FILES['video4']['name'];
    $file_temp = $_FILES['video4']['tmp_name'];
    $file_size = $_FILES['video4']['size'];
    if ($file_size < 50000000) {
        $file = explode('.', $file_name);
        $end = end($file);
        $allowed_ext = array('avi', 'flv', 'wmv', 'mov', 'mp4');
        if (in_array($end, $allowed_ext)) {
            $name = date("Ymd") . time();
            $video4 = "images/vendor-video/" . $name . "." . $end;
            move_uploaded_file($file_temp, $video4);
        }
    }

    $file = $_FILES['image1'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder1 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder1);
            }
        }
    }
    $file = $_FILES['image2'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder2 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder2);
            }
        }
    }
    $file = $_FILES['image3'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder3 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder3);
            }
        }
    }
    $file = $_FILES['image4'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder4 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder4);
            }
        }
    }
    $file = $_FILES['image5'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder5 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder5);
            }
        }
    }
    $file = $_FILES['image6'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder6 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder6);
            }
        }
    }
    $file = $_FILES['image7'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder7 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder7);
            }
        }
    }
    $file = $_FILES['image8'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder8 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder8);
            }
        }
    }
    $file = $_FILES['image9'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder9 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder9);
            }
        }
    }
    $file = $_FILES['image10'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder10 = "images/vendor/" . $file_name;
                move_uploaded_file($file_tmp, $folder10);
            }
        }
    }
    // SQL query to insert data
    $sql = "INSERT INTO vendor (v_name, v_mobile, v_alter_mobile, v_cover_pic, v_city, v_service, v_sub_category, v_address, v_about_us, v_photo_video_start_price, v_adhar_no, v_camera_brand, v_camera_modal, v_lens_gimple, v_drone_brand, v_drone_modal, v_edit_soft, v_account_no, v_ifsc_code, v_branch, v_half_day_price, v_full_day_price, v_extra_hours_price, v_image_1, v_image_2, v_image_3, v_image_4, v_image_5, v_image_6, v_image_7, v_image_8, v_image_9, v_image_10, v_video_1, v_video_2, v_video_3, v_video_4, v_video_link_1, v_video_link_2, v_video_link_3, v_video_link_4, v_term, v_promoted, v_status	)
                            VALUES ('$user', '$mobile', '$alter_mobile', '$folder','$city', '$category', '$sub_category', '$address', '$about', '$stating_price', '$adhar_no', '$camera_brand','$camera_modal', '$lens', '$drone_brand', '$drone_modal', '$software', '$account', '$account_ifsc', '$branch', '$half_price', '$full_price', '$extra_price', '$folder1', '$folder2', '$folder3', '$folder4', '$folder5', '$folder6', '$folder7', '$folder8', '$folder9', '$folder10', '$video1', '$video2', '$video3', '$video4', '$link1', '$link2', '$link3', '$link4', 'Accept', 'Not-promoted', 'Inactive')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>
        alert('Vendor Registration Successfully');
            window.location.href='../index.php';
        </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    // Close the database connection
    $conn->close();
}
