<?php include "conn.php";

$id = $_GET['id'];
$query = "DELETE FROM college_course WHERE id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert('Corse Deleted');
            window.location.href='add-college%20course.php';
        </script>";
}
