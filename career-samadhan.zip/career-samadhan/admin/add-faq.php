<?php
include "conn.php";
session_start();
if (empty($_SESSION["admin"]) && empty($_SESSION["name"])) {
    header('location:index.php');
} else {
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Add faq</title>
        <!-- META TAGS -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include 'includes/link.php'; ?>
        <script src="//cdn.ckeditor.com/4.23.0-lts/basic/ckeditor.js"></script>

    </head>

    <body data-ng-app="">
        <!--MOBILE MENU-->
        <?php include 'includes/mobile-menu.php'; ?>
        <!--HEADER SECTION-->
        <section>
            <!--TOP SECTION-->
            <?php include 'includes/menu.php'; ?>
            <!--TOP SECTION-->
            <!--DASHBOARD SECTION-->
            <div class="dashboard">
                <div class="db-left">
                    <div class="db-left-2">
                        <?php include 'includes/admin-panel.php'; ?>
                    </div>
                </div>
                <div class="db-cent">
                    <div class="db-cent-1">
                        <p>
                        
                        </p>
                        <h4>Welcome to your Dashboard</h4>
                    </div>
                    <div class="db-cent-3">
                        <div class="db-cent-table db-com-table">
                            <div class="enquiry-form">
                                <div class="form-heading">
                                    <h4>Add Faq</h4>
                                </div>
                                <div class="form-body">
                                    <form action="faq_db.php" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <!-- <div class="col-md-5">
                                                <label> Add Images</label>
                                                <input type="file" name="image" class="form-control">
                                            </div> -->


                                            <div class="col-md-5 mt-10">
                                                <label>College Name</label>
                                                <select name="college_name" class="form-control">
                                                    <option value="" disabled selected>Select College</option>
                                                    <?php
                                                    $query = "SELECT * FROM add_sub_category ORDER BY sub_cat_id asc ";
                                                    $result = mysqli_query($conn, $query);
                                                    while ($row = mysqli_fetch_assoc($result)) {
                                                    ?>
                                                        <option value="<?php echo $row['sub_cat_name']; ?>">
                                                            <?php echo $row['sub_cat_name']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-md-5">
                                                <label> Enter FAQ</label>
                                                <input type="text" name="faq" class="form-control" required >
                                            </div>
                                            <div class="col-md-5">
                                                <label> Enter FAQ ANSWER</label>
                                                <input type="text" name="faqans" class="form-control" required>
                                            </div>
                                            <div class="col-md-2">
                                                <label></label>
                                                <input type="submit" name="submit" value="Add" class="btn btn-success btn-block mt-10" class="form-control">
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="db-title">
                                <h3><img src="images/icon/dbc5.png" alt="" />Manage College FAQ</h3>
                            </div>
                            <div class="table-responsive">
                                <table id="booking" class="table table-striped table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>S no.</th>
                                             <th>College Name</th>
                                            <th>Faq</th>
                                            <th>Faq Ans</th>
                                           
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = '1';
                                        $query = "SELECT * FROM faq order by id asc";
                                        $result = mysqli_query($conn, $query);
                                        while ($row = mysqli_fetch_assoc($result)) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <?php echo $i++; ?>
                                                </td>
                                                <td>
                                                <?php echo $row['college_name']; ?>
                                                </td> 
                                                <td>
                                                    <?php echo $row['faq']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['faqans']; ?>
                                                </td>
                                                
                                                <td>
                                                    <a href="faq-delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a>
                                                </td>
                                            </tr>
                                        <?php } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--END DASHBOARD SECTION-->
        </section>
        <!--END HEADER SECTION-->

        <!--ALL SCRIPT FILES-->
        <?php include 'includes/script.php'; ?>
        <script>
            new DataTable('#booking');
            CKEDITOR.replace('editor');
        </script>
    </body>

    </html>
<?php } ?>