<?php
include "conn.php";

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
   

    // $file = $_FILES['image'];
    // $file_name = $file['name'];
    // $file_tmp = $file['tmp_name'];
    // $file_size = $file['size'];
    // $file_error = $file['error'];
    // $file_ext = explode('.', $file_name);
    // $file_ext = strtolower(end($file_ext));
    // $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    // if (in_array($file_ext, $allowed)) {
    //     if ($file_error === 0) {
    //         if ($file_size <= 2097152) {
    //             $folder = "images/category/" . $file_name;
    //             move_uploaded_file($file_tmp, $folder);
    //         }
    //     }
    // }


    // SQL query to insert data
    $sql = "INSERT INTO add_category (cat_name,cat_status) VALUES ('$name','Active')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
        alert('Add Category Successfully');
            window.location.href='add-category.php';
        </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
