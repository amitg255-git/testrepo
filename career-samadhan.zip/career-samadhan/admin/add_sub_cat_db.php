<?php
include "conn.php";

if (isset($_POST['submit'])){
    $sub_name =$_POST['sub_name'];
    $c_address=$_POST['c_address'];
    $aproved_by =$_POST['aproved_by'];
    $n_courses =$_POST['n_courses'];
    $streams=$_POST['streams'];
    $inr=$_POST['inr'];
    $sub_name =$_POST['sub_name'];

    $cat_id =$_POST['cat_id'];

    $type_college =$_POST['type_college'];
    $established =$_POST['established'];
    $location =$_POST['location'];
    $affiliation =$_POST['affiliation'];
    $ratings =$_POST['ratings'];
    $c_overview =$_POST['c_overview'];
    $fee_s =$_POST['fee_s'];

    $map =$_POST['map'];
    $rname =$_POST['rname'];
    $rating =$_POST['rating'];
    $rdate =$_POST['rdate'];
    $coment =$_POST['coment'];
    $home_c=$_POST['home_c'];
    // $tag1=$_POST['tag1'];
    // $tag2=$_POST['tag2'];
    // $tag3=$_POST['tag3'];
    // $tag4=$_POST['tag4'];
    
    






    $file = $_FILES['image'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    $file_ext = explode('.', $file_name);
    $file_ext = strtolower(end($file_ext));
    $allowed = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            if ($file_size <= 2097152) {
                $folder = "images/sub-category/" . $file_name;
                move_uploaded_file($file_tmp, $folder);
            }
        }
    }


if (isset($_FILES['image2'])) {
    $file2 = $_FILES['image2'];
    $file_name2 = $file2['name'];
    $file_tmp2 = $file2['tmp_name'];
    $file_size2 = $file2['size'];
    $file_error2 = $file2['error'];
    $file_ext2 = explode('.', $file_name2);
    $file_ext2 = strtolower(end($file_ext2));
    $allowed2 = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext2, $allowed2)) {
        if ($file_error2 === 0) {
            if ($file_size2 <= 2097152) {
                $folder2 = "images/sub-category/" . $file_name2;
                move_uploaded_file($file_tmp2, $folder2);
            }
        }
    }
}



if (isset($_FILES['image3'])) {
    $file3 = $_FILES['image3'];
    $file_name3 = $file2['name'];
    $file_tmp3 = $file3['tmp_name'];
    $file_size3 = $file3['size'];
    $file_error3 = $file3['error'];
    $file_ext3 = explode('.', $file_name3);
    $file_ext3 = strtolower(end($file_ext3));
    $allowed3 = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext3, $allowed3)) {
        if ($file_error3 === 0) {
            if ($file_size3 <= 2097152) {
                $folder3 = "images/sub-category/" . $file_name3;
                move_uploaded_file($file_tmp3, $folder3);
            }
        }
    }
}

if (isset($_FILES['image4'])) {
    $file4 = $_FILES['image4'];
    $file_name4 = $file4['name'];
    $file_tmp4 = $file4['tmp_name'];
    $file_size4 = $file4['size'];
    $file_error4 = $file4['error'];
    $file_ext4 = explode('.', $file_name4);
    $file_ext4 = strtolower(end($file_ext4));
    $allowed4 = array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext4, $allowed4)) {
        if ($file_error3 === 0) {
            if ($file_size4 <= 2097152) {
                $folder4 = "images/sub-category/" . $file_name4;
                move_uploaded_file($file_tmp4, $folder4);
            }
        }
    }
}

if (isset($_FILES['image5'])) {
    $file5 = $_FILES['image5'];
    $file_name5 = $file5['name'];
    $file_tmp5 = $file5['tmp_name'];
    $file_size5 = $file5['size'];
    $file_error5= $file5['error'];
    $file_ext5= explode('.', $file_name5);
    $file_ext5= strtolower(end($file_ext5));
    $allowed5= array('jpg', 'jpeg', 'pdf', 'png');
    if (in_array($file_ext5, $allowed5)) {
        if ($file_error5 === 0) {
            if ($file_size5 <= 2097152) {
                $folder5 = "images/sub-category/" . $file_name5;
                move_uploaded_file($file_tmp5, $folder5);
            }
        }
    }
}



    // SQL query to insert data
    $sql ="INSERT INTO add_sub_category (sub_cat_image,sub_cat_image2,image3,image4,image5,sub_cat_name,c_address,aproved_by,
    n_courses,streams,inr,
    cat_id,type_college,established,location,affiliation,ratings,c_overview,fee_s,map,rname,rating,rdate,coment,home_c,tag1,tag2,tag3,tag4,sub_cat_status) VALUES
     ('$folder','$folder2','$folder3','$folder4','$folder5', '$sub_name','$c_address','$aproved_by','$n_courses','$streams','$inr','$cat_id','$type_college','$established','$location',
     '$affiliation','$ratings','$c_overview','$fee_s','$map','$rname','$rating','$rdate','$coment','$home_c','$tag1','$tag2','$tag3','$tag4','Active')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
        alert('Add Sub Category Successfully');
            window.location.href='add-sub-category.php';
        </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
