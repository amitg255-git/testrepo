<?php
include "conn.php";

if (isset($_POST['submit'])){
    $college_name=$_POST['college_name'];
    
    $category=$_POST['category'];
    $type=$_POST['type'];
    $estd=$_POST['estd'];
    $intak=$_POST['intak'];
    $country=$_POST['country'];
    


    // SQL query to insert data
    $sql ="INSERT INTO state_college(college_name,category,type,country,estd,intak) VALUES('$college_name','$category','$type','$country',' $estd','$intak')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
        alert('college add Successfully');
            window.location.href='add-college-list.php';
        </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
