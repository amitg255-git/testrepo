<?php
include "conn.php";
session_start();
if (empty($_SESSION["admin"]) && empty($_SESSION["name"])) {
    header('location:index.php');
} else {


    
?>
                                       <?php    

                                        $id = $_GET['id'];
                                        $query = "SELECT * FROM add_sub_category WHERE sub_cat_id ='$id'";

                                        //$query = "SELECT sc.*, ac.cat_name FROM add_sub_category as sc JOIN add_category as ac ON sc.cat_id = ac.cat_id";
                                        $result = mysqli_query($conn,$query);
                                         $row = mysqli_fetch_assoc($result);
                                        ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Add Sub Category</title>
        <!-- META TAGS -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include 'includes/link.php'; ?>

    </head>

    <body data-ng-app="">
        <!--MOBILE MENU-->
        <?php include 'includes/mobile-menu.php'; ?>
        <!--HEADER SECTION-->
        <section>
            <!--TOP SECTION-->
            <?php include 'includes/menu.php'; ?>
            <!--TOP SECTION-->
            <!--DASHBOARD SECTION-->
            <div class="dashboard">
                <div class="db-left">
                    <div class="db-left-2">
                        <?php include 'includes/admin-panel.php'; ?>
                    </div>
                </div>
                <div class="db-cent">
                    <div class="db-cent-1">
                       
                        <h4>Welcome to your Dashboard</h4>
                    </div>
                    <div class="db-cent-3">
                        <div class="db-cent-table db-com-table">
                            <div class="enquiry-form">
                                <div class="form-heading">
                                    <h4>Add College</h4>
                                </div>
                                <div class="form-body">
                                    <form action="update_sub_cat_db.php" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label> Add Images</label>
                                                <input type="hidden" value="<?php echo $id ?>" name="id" class="form-control" >
                                                <input type="file" name="image" class="form-control" >
                                            </div>
                                            <!-- <div class="col-md-12">
                                                <label> Add Images2</label>
                                                <input type="file" name="image2" class="form-control" required>
                                            </div> -->

                                            <!-- <div class="col-md-12">
                                                <label> Logo1</label>
                                                <input type="file" name="image3" class="form-control" required>
                                            </div> -->
                                            <!-- <div class="col-md-12">
                                                <label>logo2</label>
                                                <input type="file" name="image4" class="form-control" required>
                                            </div> -->

                                            <div class="col-md-12">
                                                <label>Placement Baner</label>
                                                <input type="file" name="image5"  class="form-control">
                                            </div>



                                            <div class="col-md-5 mt-10">
                                                <label>College name</label>
                                                <input type="text" name="sub_name" value="<?php echo $row['sub_cat_name']; ?>" class="form-control" required>
                                            </div>
                                            <div class="col-md-5 mt-10">
                                                <label>College Address</label>
                                                <input type="text" name="c_address"  value="<?php echo $row['c_address']; ?>"class="form-control" required>
                                            </div>

                                            <div class="col-md-5 mt-10">
                                                <label>Approved By</label>
                                                <input type="text" name="aproved_by" value="<?php echo $row['aproved_by']; ?>" class="form-control" required>
                                            </div>

                                            <div class="col-md-5 mt-10">
                                                <label>No. Of Courses</label>
                                                <input type="text" name="n_courses" value="<?php echo $row['n_courses']; ?>" class="form-control" required>
                                            </div>

                                            <div class="col-md-5 mt-10">
                                                <label>Streams</label>
                                                <input type="text" name="streams"  value="<?php echo $row['streams']; ?>" class="form-control" required>
                                            </div>
                                            <div class="col-md-5 mt-10">
                                                <label>INR</label>
                                                <input type="text" name="inr" value="<?php echo $row['inr']; ?>" class="form-control" required>
                                            </div>
                                            <div class="col-md-5 mt-10">
                                                <label>Category name</label>
                                                <select name="cat_id" class="form-control" required>
                                                    <option value="" disabled selected>Select Category</option>
                                                    <?php
                                                    $query = "SELECT * FROM add_category ORDER BY cat_id asc";
                                                    $result = mysqli_query($conn, $query); 
                                                    while ($row2 = mysqli_fetch_assoc($result)) {
                                                    ?> 
                                                    <?php if($row2['cat_id']=$row['cat_id']){?>

                                                        <option value="<?php echo $row2['cat_id']; ?>" selected>
                                                            <?php echo $row2['cat_name']; ?>
                                                        </option>

                                                        <?php } ?>



                                                        <option value="<?php echo $row2['cat_id']; ?>">
                                                            <?php echo $row2['cat_name']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>

                                            <div class="col-md-5 mt-10">
                                                <label>Type of College</label>
                                                <input type="text" name="type_college" value="<?php echo $row['type_college']; ?>" class="form-control" required>
                                            </div>
                                            <div class="col-md-5 mt-10">
                                                <label>Established</label>
                                                <input type="text" name="established" value="<?php echo $row['established']; ?>" class="form-control" required>
                                            </div>
                                            <div class="col-md-5 mt-10">
                                                <label>Location</label>
                                                <input type="location" name="location" value="<?php echo $row['location']; ?>" class="form-control" required>
                                            </div>
                                            <div class="col-md-5 mt-10">
                                                <label>Affiliation</label>
                                                <input type="text" name="affiliation" value="<?php echo $row['affiliation']; ?>" class="form-control" required>
                                            </div>
                                           
                                             <div class="col-md-5 mt-10">
                                                <label>Ratings</label>
                                                <input type="text" name="ratings" value="<?php echo $row['ratings']; ?>" class="form-control" required>
                                            </div> 
                                            <div class="col-md-5 mt-10">
                                                <label>Overview</label>
                                                <input type="text" name="c_overview" value="<?php echo $row['c_overview']; ?>" class="form-control" required>
                                            </div>
                                            <!-- <div class="col-md-5 mt-10">
                                                <label>Fee Strecture</label>
                                                <input type="text" name="fee_s"  value="<?php echo $row['fee_s']; ?>" class="form-control" required>
                                            </div> -->

                                            <div class="col-md-5 mt-10">
                                                <label>Address Map</label>
                                                <input type="text" name="map" value="<?php echo $row['map']; ?>" class="form-control" required>
                                            </div>

                                            <!-- <div class="col-md-5 mt-10">
                                                <label>Review sendre name</label>
                                                <input type="text" name="rname" value="<?php echo $row['rname']; ?>" class="form-control" required>
                                            </div> -->

                                            <!-- <div class="col-md-5 mt-10">
                                                <label>Rating</label>
                                                <input type="text" name="rating"  value="<?php echo $row['rating']; ?>" class="form-control" required>
                                            </div> -->
                                            <!-- <div class="col-md-5 mt-10">
                                                <label>Review Date</label>
                                                <input type="text" name="rdate" value="<?php echo $row['rdate']; ?>" class="form-control" required>
                                            </div> -->

                                            <!-- <div class="col-md-5 mt-10">
                                                <label>Coment</label>
                                                <input type="text" name="coment" value="<?php echo $row['coment']; ?>" class="form-control" required>
                                            </div> -->
                                            <div class="col-md-5 mt-10">
                                                <label>Home Page College</label>
                                                <select name="home_c" class="form-control" required>
                                                   <?php if($row['home_c']==0){?>
                                                    <option value="0" selected>No</option>
                                                    <option value="1">Yes</option>
                                                    <?php }else{?>
                                                <option value="0">No</option>
                                                <option value="1"  selected>Yes</option>
                                                <?php }?>
                                                </select>
                                            </div>       
                                              
                                            <!-- <div class="col-md-5 mt-10">
                                                <label>Related Tag1</label>
                                                <input type="text" name="tag1" class="form-control" required>
                                            </div>
                                            <div class="col-md-5 mt-10">
                                                <label>Related Tag2</label>
                                                <input type="text" name="tag2" class="form-control" required>
                                            </div>
                                            <div class="col-md-5 mt-10">
                                                <label>Related Tag3</label>
                                                <input type="text" name="tag3" class="form-control" required>
                                            </div>
                                            <div class="col-md-5 mt-10">
                                                <label>Related Tag4</label>
                                                <input type="text" name="tag4" class="form-control" required>
                                            </div> -->
                                            
                            
                                         



                                            <div class="col-md-2 mt-10">
                                                <label></label>
                                                <input type="submit" name="submit" value="Update" class="btn btn-success btn-block mt-10" class="form-control">
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="db-title">
                                <h3><img src="images/icon/dbc5.png" alt=""/> Manage Sub Category</h3>
                            </div>
                            <div class="table-responsive">
                                <table id="booking" class="table table-striped table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>S no.</th>
                                            <th>Image</th>
                                            <!-- <th>Image2</th> -->
                                            <th>Collage Name</th>
                                            <th>Address</th>
                                            <th>Aproved_By</th>
                                            <th>Nmber of courses</th>
                                            <th>Streams</th>
                                            <th>INR</th>

                                            <th>Add date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = '1';
                                        $query = "SELECT sc.*, ac.cat_name FROM add_sub_category as sc JOIN add_category as ac ON sc.cat_id = ac.cat_id";
                                        $result = mysqli_query($conn,$query);
                                        while ($row = mysqli_fetch_assoc($result)) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <?php echo $i++; ?>
                                                </td>
                                                <td><img class="materialboxed" src="<?php echo $row['sub_cat_image']; ?>" width="50">
                                                </td>
                                                
                                                <!-- <td>
                                                     <img class="materialboxed" src="<?php //echo $row['sub_cat_image2']; ?>" width="50"> 
                                                </td>
                                                 -->
                                                <td>
                                                    <?php echo $row['sub_cat_name']; ?>
                                                </td>

                                                <td>
                                                    <?php echo $row['c_address']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['aproved_by']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['n_courses']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['streams']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['inr']; ?>
                                                </td>
                                                <td>
                                                    <?php echo $row['sub_cat_add_date']; ?>
                                                </td>
                                                <td><a href="#" class="db-success">
                                                        <?php echo $row['sub_cat_status']; ?>
                                                    </a></td>
                                                <td>
                                                    <a href="add-sub-category-delete.php?id=<?php echo $row['sub_cat_id']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a>
                                                </td>
                                            </tr>
                                        <?php } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--END DASHBOARD SECTION-->
        </section>
        <!--END HEADER SECTION-->

        <!--ALL SCRIPT FILES-->
        <?php include 'includes/script.php'; ?>
        <script>
            new DataTable('#booking');
        </script>
    </body>

    </html>
<?php } ?>