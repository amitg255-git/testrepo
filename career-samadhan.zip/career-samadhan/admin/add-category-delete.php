<?php include "conn.php";

$id = $_GET['id'];
$query = "DELETE FROM add_category WHERE cat_id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert('Category Deleted');
            window.location.href='add-category.php';
        </script>";
}
