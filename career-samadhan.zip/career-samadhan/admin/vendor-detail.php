<?php
include "conn.php";
// session_start();
if (empty($_SESSION["admin"]) && empty($_SESSION['name'])) {
    header('location:index.php');
} else {
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Vendor Detail</title>
        <!-- META TAGS -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include 'includes/link.php'; ?>
    </head>

    <body data-ng-app="">
        <!--MOBILE MENU-->
        <?php include 'includes/mobile-menu.php'; ?>
        <!--HEADER SECTION-->
        <section>
            <!--TOP SECTION-->
            <?php include 'includes/menu.php'; ?>
            <!--TOP SECTION-->
            <!--DASHBOARD SECTION-->
            <div class="dashboard">
                <div class="db-left">
                    <!-- <div class="db-left-1">
					<h4>Jana Novakova</h4>
					<p>Newyork, United States</p>
				</div> -->
                    <div class="db-left-2">
                        <?php include 'includes/admin-panel.php'; ?>
                    </div>
                </div>
                <?php
                $id =  $_GET['id'];
                $query = "SELECT vd.*, ac.cat_name FROM vendor as vd JOIN add_category as ac ON vd.v_service = ac.cat_id where vd.v_id = '$id'";
                $result = mysqli_query($conn, $query);
                $row = mysqli_fetch_assoc($result);
                ?>
                <div class="db-cent">
                    <div class="db-cent-1">
                        <p>Hi
                            <?php echo $_SESSION['name']; ?>,
                        </p>
                        <h4>Welcome to your dashboard</h4>
                    </div>
                    <div class="db-cent-3">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-3">
                                        <img src="<?php echo $row['v_cover_pic']; ?>" class="responsive-img" alt="">
                                    </div>
                                    <div class="col-md-9">
                                        <div class="db-cent-wr-con">
                                            <h2><?php echo $row['v_name']; ?></h2>
                                            <span class=" f-600 ">About us: </span>
                                            <p><?php echo $row['v_about_us']; ?></p>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h5><?php echo $row['v_add_date']; ?></h5>
                                                    <h5>mobile: <?php echo $row['v_mobile']; ?></h5>
                                                    <h5>Alternate mobile: <?php echo $row['v_alter_mobile']; ?></h5>
                                                    <h5>City: <?php echo $row['v_city']; ?></h5>
                                                    <h5>Service: <?php echo $row['cat_name']; ?></h5>
                                                    <h5>Address: <?php echo $row['v_address']; ?></h5>

                                                    <h5>Starting Price: &#8377;<?php echo $row['v_photo_video_start_price']; ?>/-</h5>
                                                </div>
                                                <div class="col-md-6">
                                                    <h5>Camera Brand: <?php echo $row['v_camera_brand']; ?></h5>
                                                    <h5>Camera Modal: <?php echo $row['v_camera_modal']; ?></h5>
                                                    <h5>Lens: <?php echo $row['v_lens_gimple']; ?></h5>
                                                    <h5>Drone Brand: <?php echo $row['v_drone_brand']; ?></h5>
                                                    <h5>Drone Modal: <?php echo $row['v_drone_modal']; ?></h5>
                                                    <h5>Editing software: <?php echo $row['v_edit_soft']; ?></h5>
                                                    <h5>Account no: <?php echo $row['v_account_no']; ?></h5>
                                                    <h5>IFSC Code: <?php echo $row['v_ifsc_code']; ?></h5>
                                                    <h5>Branch: <?php echo $row['v_branch']; ?></h5>
                                                </div>
                                            </div>


                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <h5>Half Day Price</h5>
                                    <h4>&#8377; <?php echo $row['v_half_day_price']; ?>/-</h4>
                                </div>
                                <div class="col-md-4">
                                    <h5>Full Day Price</h5>
                                    <h4>&#8377; <?php echo $row['v_full_day_price']; ?>/-</h4>
                                </div>
                                <div class="col-md-4">
                                    <h5>Extra Hours Price</h5>
                                    <h4>&#8377; <?php echo $row['v_extra_hours_price']; ?>/-</h4>
                                </div>
                            </div>
                            <h5> Image</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_1']; ?>" class="img-fluid responsive-img ">
                                </div>
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_2']; ?>" class="img-fluid responsive-img ">
                                </div>
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_3']; ?>" class="img-fluid responsive-img ">
                                </div>
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_4']; ?>" class="img-fluid responsive-img ">
                                </div>
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_5']; ?>" class="img-fluid responsive-img ">
                                </div>
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_6']; ?>" class="img-fluid responsive-img ">
                                </div>
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_7']; ?>" class="img-fluid responsive-img ">
                                </div>
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_8']; ?>" class="img-fluid responsive-img ">
                                </div>
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_9']; ?>" class="img-fluid responsive-img ">
                                </div>
                                <div class="col-md-3">
                                    <img src="<?php echo $row['v_image_10']; ?>" class="img-fluid responsive-img ">
                                </div>
                            </div>
                            <h5>Video</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-3">
                                    <video src="<?php echo $row['v_video_1']; ?>" controls width="400"></video>
                                </div>
                                <div class="col-md-3">
                                    <video src="<?php echo $row['v_video_2']; ?>" controls width="400"></video>
                                </div>
                                <div class="col-md-3">
                                    <video src="<?php echo $row['v_video_3']; ?>" controls width="400"></video>
                                </div>
                                <div class="col-md-3">
                                    <video src="<?php echo $row['v_video_4']; ?>" controls width="400"></video>
                                </div>
                            </div>
                            <h5>video Link</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-3">
                                    <?php echo $row['v_video_link_1']; ?>
                                </div>
                                <div class="col-md-3">
                                    <?php echo $row['v_video_link_2']; ?>
                                </div>
                                <div class="col-md-3">
                                    <?php echo $row['v_video_link_3']; ?>
                                </div>
                                <div class="col-md-3">
                                    <?php echo $row['v_video_link_4']; ?>
                                </div>
                            </div>
                        </div>
                        <div class="text-right pt-45">
                            <?php
                            if ($row["v_status"] == 'Active') {
                                echo ' <a href="vendor-inactive.php?id=' . $row['v_id'] . '" class="btn btn-info btn-sm"><i class="feather-trash"></i> Inactive </a>';
                            } else {
                            ?>
                                <a href="vendor-active.php?id=<?php echo $row['v_id']; ?>" class="btn btn-success btn-sm"><i class="feather-trash"></i> Active </a>
                            <?php } ?>
                        </div>
                        <div class="text-right pt-45">
                            <h4>Vendor Promoted</h4>
                            <?php
                            if ($row["v_promoted"] == 'Not-promoted') {
                                echo ' <a href="vendor-promoted.php?id=' . $row['v_id'] . '" class="btn btn-info btn-sm"><i class="feather-trash"></i>  Promoted </a>';
                            } else {
                            ?>
                                <a href="vendor-not-promoted.php?id=<?php echo $row['v_id']; ?>" class="btn btn-success btn-sm"><i class="feather-trash"></i> Not Promoted </a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php ?>
            <!--END DASHBOARD SECTION-->
            <!--TOP SECTION-->
        </section>
        <!--END HEADER SECTION-->

        <!--ALL SCRIPT FILES-->
        <?php include 'includes/script.php'; ?>
    </body>

    </html>
<?php } ?>