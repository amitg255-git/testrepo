<?php include "conn.php";

$id = $_GET['id'];
$query = "DELETE FROM add_sub_category WHERE sub_cat_id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert('Sub Category Deleted');
            window.location.href='add-sub-category.php';
        </script>";
}
