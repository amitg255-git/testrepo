<?php
include "conn.php";

if (isset($_POST['submit'])){
    $category=$_POST['category'];
    
    $course_name=$_POST['course_name'];
    $duration=$_POST['duration'];
    






    


    // SQL query to insert data
    $sql ="INSERT INTO add_course(category,course_name,duration) VALUES('$category','$course_name','$duration')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
        alert('course add Successfully');
            window.location.href='add-course.php';
        </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
