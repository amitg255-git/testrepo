<?php
include "conn.php";
?>

 <?php
    //$id = $_GET['id'];
    if (isset($_POST['submit'])) {
       
       echo  $admin_name = $_POST['admin_name'];
        //echo $admin_role = $_POST['admin_role'];
        echo $admin_mobile_no = $_POST['admin_mobile_no'];
       
       echo $query = " UPDATE admin  SET  admin_name = '$admin_name', admin_mobile_no = '$admin_mobile_no'  WHERE admin_id = '1'";
        mysqli_query($conn, $query) or die($query);
        echo "<script>
            alert('Admin Profile Successfully Update');
                window.location.href='profile.php';
            </script>";
    }

    ?>
