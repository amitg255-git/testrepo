<?php
include "conn.php";

if (isset($_POST['submit'])){
    $college_name=$_POST['college_name'];
    
    $course_name=$_POST['course_name'];
    $fee=$_POST['fee'];
    






    


    // SQL query to insert data
    $sql ="INSERT INTO college_course(college_name,course_name,fee) VALUES('$college_name','$course_name','$fee')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
        alert('course add Successfully');
            window.location.href='add-college%20course.php';
        </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
