<?php include ("conn.php");

$id = $_GET['id'];
$query = "DELETE FROM faq WHERE id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert('faq Deleted');
            window.location.href='add-faq.php';
        </script>";
}
?>