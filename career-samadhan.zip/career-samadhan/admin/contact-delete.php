<?php include "conn.php";

$id = $_GET['id'];
$query = "DELETE FROM contact WHERE con_id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert('Contact Deleted');
            window.location.href='contact-enquiry.php';
        </script>";
}
