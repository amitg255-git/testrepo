<?php include "conn.php";

$id = $_GET['id'];
$query = "DELETE FROM apply WHERE id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert(' Deleted');
            window.location.href='vendor-booking.php';
        </script>";
}
