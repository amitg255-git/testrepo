<?php include "conn.php";

$id = $_GET['id'];
$query = "DELETE FROM add_course WHERE id='$id'";
$result = mysqli_query($conn, $query) or die(mysqli_error($connect));
if ($result > 0) {
    echo "<script>
            alert('Course Deleted');
            window.location.href='add-course.php';
        </script>";
}
