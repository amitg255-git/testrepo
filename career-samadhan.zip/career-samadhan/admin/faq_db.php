<?php
include "conn.php";

if (isset($_POST['submit'])){
    $college_name=$_POST['college_name'];
    
    $faq=$_POST['faq'];
    $faqans=$_POST['faqans'];
    



    // SQL query to insert data
    $sql ="INSERT INTO faq(college_name,faq,faqans) VALUES('$college_name','$faq','$faqans')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
        alert('faq add Successfully');
            window.location.href='add-faq.php';
        </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
